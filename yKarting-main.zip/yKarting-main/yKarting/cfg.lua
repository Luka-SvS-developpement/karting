KartingCFG = {
    NomBase = "YamsBase", -- Nom Pour les Notif
    Ped = "s_m_y_westsec_01", -- Votre Ped
    PosMenu = vector3(-1026.66, -3476.28, 14.33), h = 329.33, --Menu
    KartCar = {
      {nom = "Kart Numéro 20", car = "kart20", prix = 500, spawn = vector3(-1026.77, -3491.26, 13.44), h = 61.29},
      {nom = "Kart Numéro 3", car = "kart3", prix = 200, spawn = vector3(-1025.22, -3488.49, 13.44), h = 60.15},
      {nom = "Kart TEST", car = "kart", prix = 50, spawn = vector3(-1025.22, -3488.49, 13.44), h = 60.15},
    },
}